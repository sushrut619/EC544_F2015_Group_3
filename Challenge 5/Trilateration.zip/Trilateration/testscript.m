%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is a showcase script using trilateration algorithm
% The total # of nodes in this graph is n
% Then the pair-wised distance measures will be n*(n-1)/2
% naming nodes as 1, 2,...,n; the n*(n-1)/2 distance measures are ordered
% in a sequence by the index d(1,2),%
% d(1,3),...d(1,n),d(2,3),d(2,4),...d(2,n),...,d(n-1,n)
% Thus, a measurement index matrix is generated J
%   [0 1 2 3 4 ...... n-1 ]
%   [1 0 n n+1 ...... 2n-3]
%   [2 n 0 2n-2 ..... 3n-6]
%   [.....................]
%   [.................n*(n-1)/2]
%   [n-1 ............... 0]
% The # of beacons (nodes whose position is known) is m, m should be at
%   least 3
% showcase: 6 nodes, assume their positions are
% Node1(0,3), Node2(2.5,3),Node3(2.5,0),Node4(0,0),Node5(),Node6()

n=6; % 6 nodes in total
% The pairwised distance measures are in x, 6*5/2 = 15 elements
x = [2.5,3.9051,3,1.118,2.5,3,3.9051,1.5811,1.5811,2.5,2.9155,1.5811,2.6926,2.5,1.4142]';
% generate the measurement index matrix
J = zeros(n, n);
k = 1;
for i = 1 : n
    for j = i+1 : n
        J(i,j) = k;
        k = k+1;
        J(j,i) = J(i,j);
    end
end

showcase = 2;
if showcase ==1
    % case 1: 3 beacons
    B=zeros(3,3);
    % pick any 3 from 6 nodes, for simplication using Node1, Node2, Node3
    B(1,1)=0; B(1,2)=3;
    B(2,1)=2.5; B(2,2)=3;
    B(3,1)=2.5; B(3,2)=0;
    BN = 3;
    % get the other 3 nodes' position
    P=zeros(3,2);
    for i=4:6
        for j=1:3
            B(j,3)=abs(x(J(j,i)));
        end
        [P(i-3,1),P(i-3,2)] = Trilateration(B, BN);
    end
    figure()
    plot(B(:,1),B(:,2),'bo',P(:,1),P(:,2),'r*');
    axis([-1 5 -1 5])
elseif showcase ==2
    % case 2: 4 beacons
    B=zeros(4,3);
    % pick any 4 from 6 nodes, for simplication using Node1, Node2,
    % Node3,Node4
    B(1,1)=0; B(1,2)=3;
    B(2,1)=2.5; B(2,2)=3;
    B(3,1)=2.5; B(3,2)=0;
    B(4,1)=0;B(4,2)=0;
    BN = 4;
    P=zeros(2,2);
    for i=5:6
        for j=1:4
            B(j,3)=abs(x(J(j,i)));
        end
        [P(i-4,1),P(i-4,2)] = Trilateration(B, BN);
    end
    figure()
    plot(B(:,1),B(:,2),'bo',P(:,1),P(:,2),'r*');
    axis([-1 5 -1 5])
end
